---
name: simplex-node-opencode
description: "OpenCode context and workflows for simplex-node (Saint Mary Liberty Island silver-backed digital economy)"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [Coding-Agent, OpenCode, Simplex-Node, Silver-Economy, SimpleX, Tor]
    related_skills: [opencode, claude-code, codex, hermes-agent]
---

# Simplex-Node Project Context for OpenCode

## Project Overview
**simplex-node** — Go HTTP server for Saint Mary Liberty Island (silver-backed digital economy over SimpleX/Tor). Version A3.3 (Cycle 57). Monorepo at `/home/tomas/simplex-node`.

## User's OpenCode Setup
- Binary: `~/.opencode/bin/opencode` (v1.15.13)
- Config: `~/.config/opencode/opencode.jsonc` (minimal, schema only)
- Plugins: `@opencode-ai/plugin` (1.15.13), `@kilocode/plugin` (7.3.21)
- Auth: 6 providers configured (Nvidia, xAI, GitHub Copilot, OpenCode Zen, OpenAI, OpenRouter)
- Project plans: `~/.opencode/plans/` (CONTEXT.md, PLAN-A2.md, PLAN-A1.2.md, REPORT-2026-06-05.md)

## Project Structure (Key Paths)
```
/home/tomas/simplex-node/
├── cmd/simplex-node/main.go       # Main HTTP server (~3200 LOC)
├── cmd/banknote-press/main.go     # Banknote rendering service
├── internal/                      # 33 Go packages
│   ├── economy/                   # Core economy (ledger, auction, buyback, p2p, pack, registry, etc.)
│   ├── api/                       # REST handlers
│   ├── bot/                       # 4 Telegram bots (steward, torquemada, darkpushkin, nodeapi)
│   ├── steward/                   # AI Steward with 16 constitutional rules
│   ├── treasury/                  # Silver rounds, USDT monitoring
│   ├── press/                     # Banknote templates
│   ├── vault/                     # E2EE file storage
│   └── ... (ai, gateway, ton, webrtc, radio, channels, etc.)
├── docker/                        # 4 containers: SMP, XFTP, Tor (5 HS), Coturn
├── apps/                          # Flutter apps (royal_app, isle_app, shared)
├── scripts/                       # 18 shell/Python scripts
└── docs/                          # PRODUCTION-CYCLE.md, THEPLAN.md, etc.
```

## Build/Test Commands
```bash
go build ./cmd/simplex-node/
go test ./... -short -count=1 -timeout 30s
go vet ./...
```

## Production Cycle (8-Step SOP)
Defined in `docs/PRODUCTION-CYCLE.md`:
1. BACKUP → 2. REWRITE THEPLAN → 3. REPORT TO ADMIN BOT → 4. CHOOSE STEPS → 5. BUILD → 6. TEST → 7. CREATE REPORT → 8. CALL ADMIN

## Key Economic Parameters
```
NGPerTLR = 31,103,480,000 ng (1 troy oz silver)
SilverSpotUSDperOZ = 75.0 (oracle: metals.live)
SilverBackingRatio = 0.70 (70% physical silver)
UtilityPremiumPct = 0.30 (30% utility premium)
TreasuryCommissionBPS = 228 (2.28% on all operations)
```

## Current Blockers (from THEPLAN.md)
1. **King's artifacts needed**: Ed25519 signing key, PNG/SVG banknote templates, serial number scheme, pre-mint manifests
2. **6 critical bugs**: Data races (knownRoles, islandWS), connection leaks, nil derefs, stale configs
3. **TRON USDT live monitoring** (currently simulated)
4. **Banknote press integration** (PDF rendering + Ed25519 signing)

## OpenCode Usage Patterns for This Project
- Plans stored in `~/.opencode/plans/` with CONTEXT.md + PLAN-*.md
- User runs opencode from project root: `/home/tomas/simplex-node/`
- Typical tasks: bug fixes (data races, leaks), feature work (SSE dashboard, auto-healer), refactoring main.go
- Test command: `go test ./internal/... -short -count=1 -timeout 120s`
- Always verify `go build ./cmd/simplex-node/` and `go vet ./...` after changes

## Communication Style
- User prefers direct, technical communication
- "bro" / informal tone accepted
- Values concise, actionable output over verbosity
- Wants real exploration/analysis, not summaries