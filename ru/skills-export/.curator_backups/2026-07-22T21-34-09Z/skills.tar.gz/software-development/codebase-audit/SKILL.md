---
name: codebase-audit
description: Systematic codebase audit workflow for finding bugs, security issues, and quality problems in local Go, Flutter/Dart, and script projects. Covers exploration, static analysis, bug classification, and structured reporting.
category: software-development
tags: [audit, code-quality, security, go, flutter, static-analysis, bug-hunting]
---

# Codebase Audit Skill

Systematic approach to auditing a local codebase for bugs, security vulnerabilities, and quality issues. Designed for Go + Flutter/Dart + script polyglot projects.

## Trigger Conditions
- User asks to "audit", "explore", "review", or "find bugs in" a local codebase
- Need to produce a structured bug report with severity classifications
- Comparing against a prior audit report (regression detection)

## Workflow

### Phase 1: Reconnaissance (5-10 min)
1. **Map the project structure**
   ```bash
   ls -la /path/to/project
   find /path/to/project -name "*.go" -o -name "*.dart" -o -name "*.sh" | head -50
   ```
2. **Identify entry points** — `main.go`, `main.dart`, `go.mod`, `pubspec.yaml`
3. **Check build status** — `go build ./...`, `flutter analyze`
4. **Run static analysis** — `go vet ./...`, `golangci-lint run` (if available)

### Phase 2: Deep Dive (15-30 min)
1. **Read entry points first** — understand architecture from `main.go` / `main.dart`
2. **Trace critical paths** — auth, payments, network, file I/O, concurrency
3. **Search for known bug patterns**:
   ```bash
   # Missing methods / undefined references
   grep -r "undefined" /path/to/project 2>/dev/null || go build ./... 2>&1
   
   # Goroutine leaks
   grep -r "go func()" /path/to/project --include="*.go" | grep -v "_test.go"
   
   # File descriptor leaks
   grep -r "os\.Create\|os\.OpenFile" /path/to/project --include="*.go" | grep -v "defer.*Close"
   
   # Hardcoded secrets/IPs
   grep -rE "(password|secret|api[_-]?key|192\.168\.|10\.0\.|172\.1[6-9]\.|172\.2[0-9]\.|172\.3[0-1]\.)" /path/to/project --include="*.go" --include="*.dart" | grep -v test
   
   # TODO/FIXME/BUG markers
   grep -r "TODO\|FIXME\|BUG\|XXX" /path/to/project --include="*.go" --include="*.dart"
   ```

### Phase 3: Classification & Verification
For each finding, assign severity:
- **CRITICAL** — Build fails, data loss, RCE, auth bypass
- **HIGH** — Goroutine/FD leaks, race conditions, DoS vectors
- **MEDIUM** — Logic bugs, unused code, missing context propagation, hardcoded config
- **LOW** — Dead code, unused imports, lint warnings, cosmetic

Verify each finding:
- Can it be reproduced? (build error, test failure, race detector)
- Is it a false positive? (generated code, test files, intentional)

### Phase 4: Report Generation
Produce structured markdown report with:
- Executive summary (counts by severity, build status)
- Per-bug: severity, file:line, description, reproduction steps, impact, fix
- Comparison table vs prior audit (if available)
- Prioritized action plan (immediate/short/medium/ongoing)
- File index for quick navigation

## Tool Preferences
- **Exploration**: `terminal` (ls, find, grep), `read_file`, `search_files`
- **Static analysis**: `go build`, `go vet`, `go test -race`, `flutter analyze`
- **No browser/web tools** — this is local filesystem only
- **No interactive editors** — read-only analysis

## Output Format
Markdown report saved to `<project>/AUDIT-REPORT-<DATE>.md` with:
- Severity-emoji headers (🔴 🟠 🟡 🟢 🔵)
- Reproducible commands for each finding
- Diff against prior audit (if `AUDIT-REPORT.md` exists)

## Pitfalls & Gotchas
- ❌ Don't assume `go build` passes — always run it first
- ❌ Don't skip `go test -race` — catches data races static analysis misses
- ❌ Don't trust "FIXED" claims in old reports — re-verify on current code
- ❌ Don't ignore generated/vendor files — filter with `--include/--exclude`
- ❌ Don't forget Flutter/Dart side — `flutter analyze` finds different issues
- ✅ Always check `go.mod`/`go.sum` for dependency risks
- ✅ Cross-reference findings between Go and Dart (shared API contracts)
- ✅ Use `session_search` to recall prior audit context if available
- ✅ **Handle partial builds**: if some packages fail to compile, test/vet the working ones first (`go test ./pkg/...`), then fix blockers
- ✅ **Use ad-hoc verification scripts** for targeted fix validation (see `scripts/verify-fix.sh` template)
- ✅ **Comparison mode**: when auditing against prior reports, include a diff table in output (fixed/regressed/new)
- ✅ **Race detector timeouts**: some packages (bcrypt cost=10, heavy crypto) timeout under `-race`; use `go test -race ./pkg/... -timeout 300s` per-package or lower bcrypt cost in tests
- ✅ **Build caching**: first `go build ./cmd/...` after changes may timeout (dependency resolution); retry usually succeeds
- ✅ **Flutter/Go contract drift**: check API endpoint paths, JSON field names, and WebSocket messages match between sides

## References
- `references/audit-checklist.md` — comprehensive pattern checklist
- `references/severity-guide.md` — severity calibration examples
- `templates/audit-report.md` — report template with all sections