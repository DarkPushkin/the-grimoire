#!/usr/bin/env bash
# verify-fix.sh — Quick verification script for audit fix validation
# Usage: ./verify-fix.sh <package-path> [test|vet|build|all]

set -euo pipefail

PACKAGE="${1:-./...}"
MODE="${2:-all}"

echo "=== Verifying $PACKAGE (mode: $MODE) ==="

case "$MODE" in
  build)
    go build "$PACKAGE"
    ;;
  test)
    go test -short -count=1 -timeout 60s "$PACKAGE"
    ;;
  vet)
    go vet "$PACKAGE"
    ;;
  race)
    CGO_ENABLED=1 go test -race -short -count=1 -timeout 120s "$PACKAGE"
    ;;
  all)
    go build "$PACKAGE" && go vet "$PACKAGE" && go test -short -count=1 -timeout 60s "$PACKAGE"
    ;;
  *)
    echo "Unknown mode: $MODE"
    exit 1
    ;;
esac

echo "✅ $PACKAGE passed ($MODE)"