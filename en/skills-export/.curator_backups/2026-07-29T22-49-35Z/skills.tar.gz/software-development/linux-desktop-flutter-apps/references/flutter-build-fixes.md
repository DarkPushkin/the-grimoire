# Flutter Build Fixes — Common Compilation Errors & Workarounds

## Context
This document captures recurring Flutter/Dart build issues encountered during the simplex-node/royal_app build on Linux (old hardware, Tor-proxied environment). Use as a checklist before/after major dependency upgrades or Flutter version changes.

---

## 1. flutter_gen Import Path Not Found

### Error
```
Error: Error when reading 'lib/l10n/generated/app_localizations.dart': No such file or directory
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
```

### Root Cause
`flutter_gen` package expects generated files in `.dart_tool/flutter_gen/gen_l10n/` but `flutter gen-l10n` outputs to `lib/l10n/generated/` by default (per `l10n.yaml`).

### Workaround (Manual Copy)
```bash
mkdir -p .dart_tool/flutter_gen/gen_l10n
cp lib/l10n/generated/* .dart_tool/flutter_gen/gen_l10n/
```

### Permanent Fix (pubspec.yaml)
```yaml
flutter:
  generate: true  # Enables flutter_gen
```

Then run:
```bash
flutter pub get
flutter gen-l10n
flutter pub run build_runner build --delete-conflicting-outputs
```

> **Note:** On Tor-proxied systems, `build_runner` may hang. The manual copy workaround is reliable.

---

## 2. Deprecated FontVariant.tabularNums

### Error
```
'FontVariant.tabularNums' is deprecated and shouldn't be used. Use FontFeature.tabularFigures instead.
```

### Fix
```dart
// OLD
fontVariants: [FontVariant.tabularNums],

// NEW
fontFeatures: [FontFeature.tabularFigures()],
```

### Affected Files (Pattern)
- `onboarding_screen.dart` - headlineMedium, bodyMedium
- `bridge_setup_screen.dart` - monospace text fields
- Any `TextStyle` using tabular numbers for PIN/code display

---

## 3. Icons.onion_rounded Does Not Exist

### Error
```
The getter 'onion_rounded' isn't defined for the class 'Icons'.
```

### Fix
```dart
// OLD
Icon(Icons.onion_rounded)

// NEW - Use security icon for Tor/onion routing
Icon(Icons.security_rounded)
```

---

## 4. Reserved Keyword 'continue' in Localization

### Error
```
'continue' is a reserved keyword and cannot be used as an identifier.
```

### Fix in ARB Files
```json
// app_en.arb
{
  "continueAction": "Continue"
}

// app_ru.arb
{
  "continueAction": "Продолжить"
}
```

### Usage in Dart
```dart
// OLD (breaks)
Text(l10n.continue)

// NEW
Text(l10n.continueAction)
```

---

## 5. Null Safety for String? Fields

### Pattern: Optional Config Strings
```dart
// Field declaration
String? _simplexNodeConfig;

// Null-safe checks
if ((_simplexNodeConfig?.isNotEmpty ?? false)) { ... }

// Safe display
Text(_simplexNodeConfig?.isEmpty ?? true ? 'Not configured' : _simplexNodeConfig!)

// Safe controller initialization
TextEditingController(text: widget.simplexNodeConfig ?? '')
```

### SharedPreferences Save
```dart
// OLD (crashes on null)
await _prefs.setString('simplex_node_config', _simplexNodeConfig);

// NEW
if ((_simplexNodeConfig?.isNotEmpty ?? false)) {
  await _prefs.setString('simplex_node_config', _simplexNodeConfig!);
}
```

---

## 6. AppLocalizations Initialization Pattern

### Correct Pattern for State Classes
```dart
class _MyScreenState extends State<MyScreen> {
  late AppLocalizations _l10n;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _l10n = AppLocalizations.of(context)!;
  }

  @override
  Widget build(BuildContext context) {
    // Use _l10n here
    return Text(_l10n.someKey);
  }
}
```

### Anti-Patterns to Avoid
```dart
// ❌ BAD: Calling in initState - context not ready
@override
void initState() {
  _l10n = AppLocalizations.of(context)!; // CRASH
}

// ❌ BAD: Direct import from wrong path
import 'package:royal_app/l10n/generated/app_localizations.dart';

// ✅ GOOD: Use flutter_gen import
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
```

---

## 7. Missing dart:async Import for Timer

### Error
```
Type 'Timer' not found.
```

### Fix
```dart
import 'dart:async';  // Add at top of file
```

### Affected Files
- `lock_screen.dart` - uses `Timer.periodic` for lockout countdown

---

## 8. Localization Keys Added This Session

### English (app_en.arb)
```json
{
  "russianDetected": "Russian detected",
  "englishDetected": "English detected",
  "bootMessage": "Booting Royal Control"
}
```

### Russian (app_ru.arb)
```json
{
  "russianDetected": "Русский язык обнаружен",
  "englishDetected": "Английский язык обнаружен",
  "bootMessage": "Загрузка Royal Control"
}
```

---

## 9. AppState Methods Required by Screens

### Missing Methods (Added to main.dart)
```dart
class AppState extends ChangeNotifier {
  // ... existing fields ...

  void setIdentity(Identity identity) {
    _identity = identity;
    notifyListeners();
  }

  void setUnlocked(bool v) {
    unlocked = v;
    notifyListeners();
  }
}
```

### Usage in Screens
```dart
final appState = context.read<AppState>();
appState.setIdentity(identity);
appState.setUnlocked(true);
```

---

## 10. ProfileSelectionScreen Navigation Fix

### Issue
ProfileSelectionScreen expected `onProfileActivated` callback with profile + PIN, but LockScreen only had `onUnlocked`.

### Fix
Update LockScreen constructor:
```dart
class LockScreen extends StatefulWidget {
  final String profileId;
  final VoidCallback onUnlocked;
  final VoidCallback? onBackToProfiles;
  final VoidCallback? onRecoverFromSeed;
  final String? initialError;

  // NEW: For ProfileSelectionScreen integration
  final ValueChanged<ProfileInfo>? onProfileSelected;

  const LockScreen({
    super.key,
    required this.profileId,
    required this.onUnlocked,
    this.onBackToProfiles,
    this.onRecoverFromSeed,
    this.initialError,
    this.onProfileSelected,  // NEW
  });
}
```

---

## 11. Complete Build Command (Tor-Proxied Systems)

```bash
# 1. Stop memory-heavy services
pkill -f simplex-node
pkill -f paranoidx
pkill -f "node.*monitor"
pkill -f v2raya
pkill -f "xray run"

# 2. Free port 10808 if held by docker-proxy
ss -tlnp | grep :10808 && kill $(ss -tlnp | grep :10808 | awk '{print $NF}' | cut -d= -f2)

# 3. Clean build artifacts
rm -rf apps/royal_app/build .dart_tool

# 4. Generate l10n & copy for flutter_gen
flutter gen-l10n
mkdir -p .dart_tool/flutter_gen/gen_l10n
cp lib/l10n/generated/* .dart_tool/flutter_gen/gen_l10n/

# 5. Build with proxy unset
env -u http_proxy -u https_proxy -u HTTP_PROXY -u HTTPS_PROXY -u ALL_PROXY -u all_proxy \
flutter build linux --release

# 6. Verify binary
ls -la build/linux/x64/release/bundle/royal_app
file build/linux/x64/release/bundle/royal_app
```

---

## 12. Verification Checklist Before Commit

- [ ] All screens import `flutter_gen/gen_l10n/app_localizations.dart`
- [ ] No `FontVariant.tabularNums` — all use `FontFeature.tabularFigures()`
- [ ] No `Icons.onion_rounded` — use `Icons.security_rounded`
- [ ] No `l10n.continue` — use `l10n.continueAction`
- [ ] All `String?` fields use `??` or `?.` operators
- [ ] `didChangeDependencies()` used for `AppLocalizations.of(context)!`
- [ ] `import 'dart:async';` in files using `Timer`
- [ ] `pubspec.yaml` has `flutter: generate: true`
- [ ] ARB files have `continueAction`, `russianDetected`, `englishDetected`, `bootMessage`
- [ ] `AppState` has `setIdentity()` and `setUnlocked()` methods

---

## Session-Specific Fixes (2026-07-28)

### Files Modified
- `lib/main.dart` - imports, AppState methods, localizationsDelegates
- `lib/screens/boot_screen.dart` - imports, _l10n init, language detection
- `lib/screens/bridge_setup_screen.dart` - imports, null safety, dialog params
- `lib/screens/onboarding_screen.dart` - imports, _pinObscure field, hashPin via context.read
- `lib/screens/lock_screen.dart` - imports, Timer import, _l10n init
- `lib/screens/registration_screen.dart` - imports, Random import
- `lib/l10n/app_en.arb` / `app_ru.arb` - new keys
- `pubspec.yaml` - `generate: true`, `build_runner` dev dependency

### Key Workarounds Applied
1. Manual copy of l10n generated files to `.dart_tool/flutter_gen/gen_l10n/`
2. Changed `localizationsDelegates` from `const` to mutable list to allow `AppLocalizations.delegate`
3. Fixed `_BridgeConfigDialog` constructor parameter type `String? simplexNodeConfig`
4. Fixed `_PinEntryField` widget parameter names (`_pinObscure` vs `_obscurePin`)