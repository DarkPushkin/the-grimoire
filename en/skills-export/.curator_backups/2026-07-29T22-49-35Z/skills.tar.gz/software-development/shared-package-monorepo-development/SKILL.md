---
name: shared-package-monorepo-development
description: "Flutter/Go monorepo with path deps for blocked pub.dev."
trigger: Monorepo with shared Dart packages (models, api_client, widgets) where pub.dev is blocked, requiring path dependencies and model-first development.
---

# Shared Package Monorepo Development

## Context
Monorepos with:
- **Flutter apps** (citizen + admin)
- **Shared Dart packages**: `models`, `api_client`, `widgets`
- **Go backend** with HTTP API
- **Network constraints**: Tor proxy blocks `pub.dev` -> must use `path:` dependencies
- **Static analysis**: `flutter analyze --no-pub` times out -> use `dart analyze <file>` per-file

## Core Patterns

### 1. Model-First Development
**Define shared models before screens that consume them.**
- Backend Go handlers define JSON response shape
- Dart models in `shared/models/lib/src/` must match both:
  - Backend JSON field names (snake_case to camelCase via manual `fromJson`)
  - Frontend screen field access patterns
- Missing models cause cascade of `undefined_class` / `undefined_getter` errors

### 2. Path Dependencies (Tor Proxy Workaround)
```yaml
# In each app's pubspec.yaml
dependencies:
  models:
    path: ../shared/models
  api_client:
    path: ../shared/api_client
  widgets:
    path: ../shared/widgets
```
- **Never use `git:` dependencies** -- Tor proxy blocks GitHub
- Run `flutter pub get` in each app directory after model changes
- If `flutter pub get` fails, `dart analyze` still works for syntax checking

### 3. Static Analysis Workflow
```bash
# Full analyze times out (120s+)
# Per-file analyze is fast (<2s)
dart analyze apps/isle_app/lib/screens/royal_screen.dart
dart analyze apps/isle_app/lib/screens/
```
- Fix errors screen-by-screen
- Warnings (unused imports, prefer_const) are non-blocking
- Exit code 0 = clean, 3 = errors

### 4. API Client Architecture
- **Single unified client**: `SimplexApiClient` in `shared/api_client`
- **Typed domain sub-clients**: `WalletApi`, `MarketApi`, `RoyalClient`, `SystemApi`, `ChatApi`, `RadioApi`, `VaultApi`, `PosApi`, `ParanoidXApi`, `TreasuryApi`, `GovernanceApi`, `EconomyApi`
- **Interceptors**: Auth (Ed25519 signatures), logging, timeout (30s), retry
- **WebSocket**: For real-time chat/radio
- **Offline cache**: Drift/SQLite for read-heavy endpoints

### 5. Phase-Based Evolution (simplex-node pattern)
| Phase | Focus | Status |
|-------|-------|--------|
| 0 | BIP39 identity, shared packages, iOS/Android build fix | Done |
| 1 | Unified SimplexApiClient (onion routing, typed endpoints, WS, cache) | Done |
| 2 | Isle citizen screens to SimplexApiClient + shared models | Done (11/11) |
| 3 | Royal admin screens to SimplexApiClient (migrate from legacy royal_api_service) | In Progress |
| 4 | Differentiators: pairing, TLR-TL, bonds, staking, POS, mesh | Pending |

## Pitfalls & Fixes

### Missing Model Fields
**Symptom**: `The getter 'fieldName' isn't defined for the type 'ModelClass'`
**Fix**: Check backend Go handler JSON output -> add field to Dart model -> run `dart analyze` on dependent screens

### Model/Backend Mismatch
**Symptom**: `type 'int' is not a subtype of type 'double'` or null errors
**Fix**: Go uses `int64` for ng amounts -> Dart `int`; optional fields -> nullable with `??` defaults in `fromJson`

### Screen Uses Fields Model Doesn't Have
**Symptom**: Screen references `model.serial`, `model.grade` but model has `id`, `itemId`
**Fix**: Either extend model with computed getters OR refactor screen to use actual model fields

### Unused Import Warnings After Model Moves
**Fix**: `dart fix --apply` on the app directory, or manually remove unused `show` clauses

### TabBarView Children Count Mismatch
**Symptom**: `TabBarView` children length != `TabBar` tabs length
**Fix**: Ensure `TabController(length: N)` matches both `TabBar(tabs: [...].length == N)` and `TabBarView(children: [...].length == N)`

## Verification Checklist
After model changes:
- [ ] `dart analyze apps/shared/models/lib/src/` -- models clean
- [ ] `dart analyze apps/isle_app/lib/screens/<changed_screen>.dart` -- each screen clean
- [ ] `dart analyze apps/royal_app/lib/screens/` -- admin screens clean (if migrated)
- [ ] Run `go build ./cmd/simplex-node/` -- backend compiles
- [ ] Check API client sub-clients use updated models

## Related Skills
- `autonomous-ai-agents/simplex-node-opencode` -- Project-specific OpenCode workflows for 20-cycle evolution
- `software-development/test-driven-development` -- RED-GREEN-REFACTOR for new endpoints
- `software-development/systematic-debugging` -- 4-phase root cause for analysis failures