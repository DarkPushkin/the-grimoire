---
name: simplex-node-opencode
description: "OpenCode context and workflows for simplex-node (Saint Mary Liberty Island silver-backed digital economy)"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [Coding-Agent, OpenCode, Simplex-Node, Silver-Economy, SimpleX, Tor]
    related_skills: [opencode, claude-code, codex, hermes-agent]
---

# Simplex-Node Project Context for OpenCode

## Project Overview
**simplex-node** — Go HTTP server for Saint Mary Liberty Island (silver-backed digital economy over SimpleX/Tor). Version A3.3 (Cycle 57). Monorepo at `/home/tomas/simplex-node`.

## User's OpenCode Setup
- Binary: `~/.opencode/bin/opencode` (v1.15.13)
- Config: `~/.config/opencode/opencode.jsonc` (minimal, schema only)
- Plugins: `@opencode-ai/plugin` (1.15.13), `@kilocode/plugin` (7.3.21)
- Auth: 6 providers configured (Nvidia, xAI, GitHub Copilot, OpenCode Zen, OpenAI, OpenRouter)
- Project plans: `~/.opencode/plans/` (CONTEXT.md, PLAN-A2.md, PLAN-A1.2.md, REPORT-2026-06-05.md)

## Project Structure (Key Paths)
```
/home/tomas/simplex-node/
├── cmd/simplex-node/main.go       # Main HTTP server (~3200 LOC)
├── cmd/banknote-press/main.go     # Banknote rendering service
├── internal/                      # 33 Go packages
│   ├── economy/                   # Core economy (ledger, auction, buyback, p2p, pack, registry, etc.)
│   ├── api/                       # REST handlers
│   ├── bot/                       # 4 Telegram bots (steward, torquemada, darkpushkin, nodeapi)
│   ├── steward/                   # AI Steward with 16 constitutional rules
│   ├── treasury/                  # Silver rounds, USDT monitoring
│   ├── press/                     # Banknote templates
│   ├── vault/                     # E2EE file storage
│   └── ... (ai, gateway, ton, webrtc, radio, channels, etc.)
├── docker/                        # 4 containers: SMP, XFTP, Tor (5 HS), Coturn
├── apps/                          # Flutter apps (royal_app, isle_app, shared)
├── scripts/                       # 18 shell/Python scripts
└── docs/                          # PRODUCTION-CYCLE.md, THEPLAN.md, etc.
```

## Build/Test Commands
```bash
go build ./cmd/simplex-node/
go test ./... -short -count=1 -timeout 30s
go vet ./...
```

## Production Cycle (8-Step SOP)
Defined in `docs/PRODUCTION-CYCLE.md`:
1. BACKUP → 2. REWRITE THEPLAN → 3. REPORT TO ADMIN BOT → 4. CHOOSE STEPS → 5. BUILD → 6. TEST → 7. CREATE REPORT → 8. CALL ADMIN

## Key Economic Parameters
## Flutter Monorepo Architecture
See `references/flutter-monorepo-architecture.md` and `references/simplex-node-audit-2026-07-29.md` for detailed structure of:
- Shared packages: `models`, `api_client`, `widgets` (path dependencies)
- Unified `SimplexApiClient` with onion routing, typed endpoints, SSE, offline queue
- Isle app (9 tabs): Dashboard, Wallet, Market, Vault, Radio, Chat, ParanoidX, POS, Royal
- Royal app (8 admin screens): Dashboard, AI Office, Treasury, Comms, DC Cloud, Governance, System, Settings
- ParanoidX native engine: 4-layer proxy chain (V2Ray→VPN→Tor→SimpleX) via Kotlin MethodChannel

## Key Economic Parameters
``` NGPerTLR = 31,103,480,000 ng (1 troy oz silver)
SilverSpotUSDperOZ = 75.0 (oracle: metals.live)
SilverBackingRatio = 0.70 (70% physical silver)
UtilityPremiumPct = 0.30 (30% utility premium)
TreasuryCommissionBPS = 228 (2.28% on all operations)
```

## Current Blockers
1. **King's artifacts needed**: Ed25519 signing key, PNG/SVG banknote templates, serial number scheme, pre-mint manifests
2. **6 critical bugs**: Data races (knownRoles, islandWS), connection leaks, nil derefs, stale configs
3. **TRON USDT live monitoring** (currently simulated)
4. **Banknote press integration** (PDF rendering + Ed25519 signing)

## Key Learnings (Cycle 57 / A3.3)

### Desktop Shortcut Debugging (Isle App + Royal App)
- **Root cause**: `.desktop` files pointed to `build/linux/x64/release/bundle/` but `install.sh` installs to `~/.local/bin/the-isle/isle_app` and `~/.local/bin/the-royal/royal_app`
- **Fix**: Update `.desktop` Exec paths to installed binaries, copy to `~/.local/share/applications/` and `~/Desktop/`, ensure icons in `~/.local/share/icons/hicolor/512x512/apps/`, run `update-desktop-database`
- **Validation**: `desktop-file-validate` passes for both

### V2Ray VMess → VLESS+Reality Migration (Complete)
- **Trigger**: Xray-core 26.3.27+ deprecates VMess (no forward secrecy, fingerprintable)
- **Ports**: VLESS client :10810, VLESS server :10813 (non-root), VMess legacy :10812 (to retire)
- **Key files**: `scripts/setup-vless.sh`, `internal/api/paranoidx_vless.go`, `scripts/logrotate-simplex-node`
- **Systemd**: User services at `~/.config/systemd/user/vless-server.service` and `v2raya.service`

### USB Backup Binary Recovery
- When Flutter build fails (bip32 version conflict + Tor proxy), USB backup at `/run/media/tomas/SIMPLEX-USB/backups/simplex-node-backup-*.tar.gz` contains working binaries
- Extract → locate binaries → copy to `~/.local/bin/` → verify → update shortcuts

### Flutter Dependency Conflict Resolution
- `bip32 ^3.0.0` not found on pub.dev → downgrade to `bip32 ^2.0.0` in `apps/shared/models/pubspec.yaml`
- Run `flutter pub get` in shared package FIRST, then dependent apps
- Unset proxy env vars: `env -u http_proxy -u https_proxy ... flutter pub get`

### Ad-Hoc Verification Script Pattern
Created `/tmp/hermes-verify-simplex-node.sh` checking:
- Go syntax (`gofmt -e`)
- Shell syntax (`bash -n`)
- Logrotate syntax (`logrotate --debug`)
- Desktop file validation
- Binary executability & icon presence
- Process cleanup (no root v2rayA, port 10808 freed)
- Expected Xray processes running (3)
- New files created
- Disk space improvement

## OpenCode Usage Patterns for This Project
- Plans stored in `~/.opencode/plans/` with CONTEXT.md + PLAN-*.md
- User runs opencode from project root: `/home/tomas/simplex-node/`
- Typical tasks: bug fixes (data races, leaks), feature work (SSE dashboard, auto-healer), refactoring main.go
- Test command: `go test ./internal/... -short -count=1 -timeout 120s`
- Always verify `go build ./cmd/simplex-node/` and `go vet ./...` after changes

## Communication Style
- User prefers direct, technical communication
- "bro" / informal tone accepted
- Values concise, actionable output over verbosity
- Wants real exploration/analysis, not summaries